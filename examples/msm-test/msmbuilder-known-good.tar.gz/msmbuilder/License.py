# This file is part of MSMBuilder.
#
# Copyright 2011 Stanford University
#
# MSMBuilder is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

LicenseString="""--------------------------------------------------------------------------------

MSMBuilder version 2.0.0

See file AUTHORS for a list of MSMBuilder contributors.

--------------------------------------------------------------------------------

Copyright 2011 Stanford University.

MSMBuilder comes with ABSOLUTELY NO WARRANTY.

MSMBuilder is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

--------------------------------------------------------------------------------"""

def PrintLicense():
  """Prints the license."""
  print(LicenseString)

PrintLicense()
